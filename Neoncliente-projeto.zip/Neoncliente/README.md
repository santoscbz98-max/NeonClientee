# Neon Client — Minecraft Java 1.8.9

Projeto inicial de mod Forge para Minecraft 1.8.9, pensado para PojavLauncher.

## Recursos incluídos
- Menu abre com **RSHIFT**
- Interface Neon Client
- ToggleSprint básico

## Como compilar
O workflow do GitHub Actions compila automaticamente quando você envia os arquivos para a branch `main`, ou pode ser iniciado em Actions > Compilar Neon Client > Run workflow.

O arquivo JAR deve aparecer em Artifacts com o nome `Neon-Client`.

## Instalação no Android
1. Use uma instalação Minecraft Java **1.8.9 com Forge 11.15.1.2318** no PojavLauncher.
2. Baixe o artifact `Neon-Client` e extraia o ZIP.
3. Copie `NeonClient-1.0.jar` para `.minecraft/mods`.
4. Inicie o perfil Forge 1.8.9.

Este é um projeto inicial. Os módulos avançados (HUD, CPS, KeyStrokes, coordenadas e crosshair customizado) ainda não estão implementados.
