package br.neonclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;

@Mod(modid = NeonClient.MODID, name = NeonClient.NAME, version = NeonClient.VERSION, clientSideOnly = true)
public class NeonClient {
    public static final String MODID = "neonclient";
    public static final String NAME = "Neon Client";
    public static final String VERSION = "1.0";

    private static KeyBinding menuKey;
    private static boolean sprintEnabled = false;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        menuKey = new KeyBinding("Neon Client Menu", Keyboard.KEY_RSHIFT, "Neon Client");
        ClientRegistry.registerKeyBinding(menuKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (menuKey != null && menuKey.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new NeonMenu());
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && sprintEnabled) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null && mc.gameSettings.keyBindForward.isKeyDown()) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

    public static void setSprintEnabled(boolean enabled) {
        sprintEnabled = enabled;
    }

    public static boolean isSprintEnabled() {
        return sprintEnabled;
    }
}
