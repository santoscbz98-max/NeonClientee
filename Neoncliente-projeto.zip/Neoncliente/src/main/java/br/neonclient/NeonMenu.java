package br.neonclient;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import java.io.IOException;

public class NeonMenu extends GuiScreen {
    private boolean sprint;

    @Override
    public void initGui() {
        this.buttonList.clear();
        this.sprint = NeonClient.isSprintEnabled();
        this.buttonList.add(new GuiButton(1, this.width / 2 - 100, this.height / 2 - 24, 200, 20,
                "ToggleSprint: " + (sprint ? "ON" : "OFF")));
        this.buttonList.add(new GuiButton(2, this.width / 2 - 100, this.height / 2 + 4, 200, 20, "Fechar"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            sprint = !sprint;
            NeonClient.setSprintEnabled(sprint);
            button.displayString = "ToggleSprint: " + (sprint ? "ON" : "OFF");
        } else if (button.id == 2) {
            this.mc.displayGuiScreen(null);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, "NEON CLIENT", this.width / 2, this.height / 2 - 60, 0x55FFFF);
        this.drawCenteredString(this.fontRendererObj, "Minecraft 1.8.9", this.width / 2, this.height / 2 - 43, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
